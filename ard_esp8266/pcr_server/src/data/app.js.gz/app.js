angular.module('myApp', ['ngMaterial'])
	.controller('AppCtrl', function ($scope, $http, $timeout) {

		$scope.settings = [
		];

		$scope.editing = undefined;

		var load_settings = function() {
			$http.get('settings.json').then(function(response) {
				$scope.settings = response.data.settings;
				console.log('load success', response.data);
			}, function(response) {
				console.log('load error', response.data);
			});
		}

		$scope.edit = function(s) {
			$scope.editing = s || {};
		}

		$scope.submit = function() {
		}

		load_settings();

	});

