import { getUsefulContents } from './module.js';

document.addEventListener('keydown', function(ev) {
	console.log(ev);
	document.getElementById('output').innerText=ev.keyCode;
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		document.getElementById("info").innerHTML = this.responseText;
	};
	xhttp.open("GET", "ajax_info.php?key=" + ev.keyCode, true);
	xhttp.send();
});

angular.module('myApp', ['ngMaterial']).controller('AppCtrl', function ($scope, $http, $timeout) {

	$scope.button_click = function() {
		$timeout(function() {
			getUsefulContents('http://www.example.com', data => {
				console.log('Got data', data);
			});
		});
	}

});
