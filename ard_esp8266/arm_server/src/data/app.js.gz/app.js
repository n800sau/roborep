angular.module('myApp', ['ngMaterial'])
	.controller('AppCtrl', function ($scope, $http, $timeout) {

		$scope.settings = [
				{
					s_id: 'one',
					vmin: 0,
					vmax: 180,
				},
				{
					s_id: 'two',
					vmin: 0,
					vmax: 180,
				},
				{
					s_id: 'three',
					vmin: 0,
					vmax: 180,
				},
				{
					s_id: 'four',
					vmin: 0,
					vmax: 180,
				},
			];

		$scope.values = {
			one: 90,
			two: 90,
			three: 90,
			four: 90,
		};

		$scope.item_enabled = {
			one: false,
			two: false,
			three: false,
			four: false,
		}

		var save_values_promise = undefined;

		var save_values_debounce = function(timeout) {
			timeout = timeout || 100;
			if(save_values_promise) {
				$timeout.cancel(save_values_promise);
			}
			save_values_promise = $timeout(save_values, timeout);
		}

		var save_values = function() {
			var params = {};
			for(var k in $scope.values) {
				params[k] = $scope.item_enabled[k] ? $scope.values[k] : -1;
			}
			$http.post('store_values', {
				values: params
			}).then(
				function(response) {
					console.log('success', response.data);
				}, function(response) {
					console.log('error', response.data);
				}
			);
		}

		var save_settings_promise = undefined;

		var save_settings_debounce = function(timeout) {
			timeout = timeout || 1000;
			if(save_settings_promise) {
				$timeout.cancel(save_settings_promise);
			}
			save_settings_promise = $timeout(save_settings, timeout);
		}

		var save_settings = function() {
			$http.post('store_settings', {settings: $scope.settings}).then(function(response) {
				console.log('success', response.data);
			}, function(response) {
				console.log('error', response.data);
			});
		}

		$scope.$watch('values', function(newVal, oldVal) {
			console.log('vals', oldVal, '->', newVal);
			save_values_debounce();
		}, true);

		$scope.$watch('item_enabled', function(newVal, oldVal) {
			console.log('en', oldVal, '->', newVal);
			save_values_debounce();
		}, true);

		$scope.$watch('settings', function(newVal, oldVal) {
			console.log('changed from', oldVal, ' to ', newVal);
			save_settings_debounce();
		}, true);

		var load_settings = function() {
			$http.get('settings').then(function(response) {
				$scope.settings = response.data.settings;
				console.log('load success', response.data);
			}, function(response) {
				console.log('load error', response.data);
			});
		}

		load_settings();

	});

