angular.module('myApp', ['ngMaterial'])
	.controller('AppCtrl', function ($scope, $http, $timeout) {

		$scope.settings = [
		];

		$scope.editing = undefined;
		$scope.heating = undefined;
		$scope.cooling = undefined;

		$scope.y_scale = function() {
			var min = Math.floor($scope.min_temp()/10);
			var max = Math.floor($scope.max_temp()/10);
			return Array.from(Array(max-min+1).keys()).map(function(v) { return (v+min)*10; });
		}

		$scope.templist = [];
		$scope.temp2set = 36;
		$scope.temp2set_confirmed = undefined;

		$scope.min_temp = function() {
			return $scope.templist.length >= 2 ? Math.floor(Math.min.apply(null, $scope.templist)/10)*10 : 20;
		}

		$scope.max_temp = function() {
			return Math.max($scope.templist.length >= 2 ? Math.ceil(Math.max.apply(null, $scope.templist)/10)*10 : 30, $scope.temp2set_confirmed || 0);
		}

		$scope.plot_width = 150;
		$scope.plot_height = 100;


		$scope.x_scale = function() {
			var templist = $scope.templist || [];
			var arr = Array((templist.length > 2 ? templist.length : 2)-1)
			return Array.from(arr.keys());
		}

		$scope.get_templist = function() {
			return $scope.templist.slice(-20);
		}

		var addMessage = function(text) {
			$scope.message = text;
			$scope.$digest();
		}

		var startSocket = function() {
			ws = new WebSocket('ws://'+document.location.host+'/ws',['arduino']);
			ws.binaryType = "arraybuffer";
			ws.onopen = function(e){
				addMessage("Connected");
			};
			ws.onclose = function(e){
				addMessage("Disconnected");
			};
			ws.onerror = function(e){
				console.log("ws error", e);
				addMessage("Error");
			};
			ws.onmessage = function(e){
				data = JSON.parse(e.data);
				if(data.temp !== undefined) {
					$scope.heating = data.heating;
					$scope.cooling = data.cooling;
					$scope.templist.push(data.temp);
					if($scope.templist.length > 100) {
						$scope.templist.shift();
					}
					$scope.$apply();
				}
			};
		}

		var load_settings = function() {
			$http.get('settings.json').then(function(response) {
				$scope.settings = response.data.settings;
				console.log('load success', response.data);
			}, function(response) {
				console.log('load error', response.data);
			});
		}

		$scope.edit = function(s) {
			$scope.editing = s || {};
		}

		$scope.submit = function() {
		}

		$scope.apply = function(temp) {
			$http.post('temp/set', {
					temp: temp
				}, {
					headers: {
						'Content-Type': 'application/json',
					},
			}).then(function(response) {
					$scope.temp2set_confirmed = response.data.temp2set;
			}, function(response) {
				console.log('apply error', response.data);
			});
		}

		load_settings();
		startSocket();

	});

