angular.module('myApp', ['ngMaterial'])
	.controller('AppCtrl', function ($scope, $http, $timeout) {

		$scope.settings = [
		];

		$scope.editing = undefined;

		$scope.templist = [];
		$scope.min_temp = 23;
		$scope.max_temp = 28;

		$scope.plot_width = 150;
		$scope.plot_height = 100;

		$scope.temp_plot = {
			type : 'line',
			series : [
				{ values : $scope.templist },
			]
		};

		var addMessage = function(text) {
			$scope.message = text;
			$scope.$digest();
		}

		var startSocket = function() {
			ws = new WebSocket('ws://'+document.location.host+'/ws',['arduino']);
			ws.binaryType = "arraybuffer";
			ws.onopen = function(e){
				addMessage("Connected");
			};
			ws.onclose = function(e){
				addMessage("Disconnected");
			};
			ws.onerror = function(e){
				console.log("ws error", e);
				addMessage("Error");
			};
			ws.onmessage = function(e){
				data = JSON.parse(e.data);
				if(data.temp !== undefined) {
					$scope.templist.push(data.temp);
					if($scope.templist.length > 100) {
						$scope.templist.shift();
					}
					console.log($scope.templist);
					$scope.$apply();
				}
			};
		}

		var load_settings = function() {
			$http.get('settings.json').then(function(response) {
				$scope.settings = response.data.settings;
				console.log('load success', response.data);
			}, function(response) {
				console.log('load error', response.data);
			});
		}

		$scope.edit = function(s) {
			$scope.editing = s || {};
		}

		$scope.submit = function() {
		}

		load_settings();
		startSocket();

	});

